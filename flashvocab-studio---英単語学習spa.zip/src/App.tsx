/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  BookOpen,
  Plus,
  BrainCircuit,
  BarChart3,
  Volume2,
  RotateCw,
  ChevronLeft,
  ChevronRight,
  CheckCircle2,
  XCircle,
  Trash2,
  Search,
  Key,
  Sparkles,
  Shuffle,
  Check,
  RotateCcw,
  Eye,
  EyeOff,
  Flame,
  Award,
  Download,
} from 'lucide-react';

// ============================================================================
// Types & Interfaces
// ============================================================================

export interface WordItem {
  id: string;
  word: string;
  meaning: string;
  partOfSpeech: string;
  mastered: boolean;
  createdAt: number;
}

export interface QuizQuestion {
  targetWord: string;
  targetMeaning: string;
  sentence: string;
  choices: string[];
  correctIndex: number;
  translation: string;
  explanation: string;
  isAiGenerated: boolean;
}

export interface QuizHistoryRecord {
  timestamp: number;
  dateStr: string;
  correct: boolean;
  targetWord: string;
}

export interface QuizStats {
  totalAnswered: number;
  correctCount: number;
  currentStreak: number;
  bestStreak: number;
  history: QuizHistoryRecord[];
}

type TabType = 'flashcard' | 'register' | 'quiz' | 'dashboard';

// ============================================================================
// Default High-Frequency TOEIC & Daily Vocabulary Presets
// ============================================================================

const DEFAULT_PRESET_WORDS: WordItem[] = [
  { id: 'w1', word: 'resilient', meaning: '回復力がある、立ち直りが早い', partOfSpeech: '形容詞', mastered: true, createdAt: Date.now() - 1500000 },
  { id: 'w2', word: 'facilitate', meaning: 'を促進する、容易にする', partOfSpeech: '動詞', mastered: false, createdAt: Date.now() - 1400000 },
  { id: 'w3', word: 'unprecedented', meaning: '前例のない、空前の', partOfSpeech: '形容詞', mastered: false, createdAt: Date.now() - 1300000 },
  { id: 'w4', word: 'implement', meaning: 'を実行する、導入する', partOfSpeech: '動詞', mastered: true, createdAt: Date.now() - 1200000 },
  { id: 'w5', word: 'meticulous', meaning: '細心の注意を払った、緻密な', partOfSpeech: '形容詞', mastered: false, createdAt: Date.now() - 1100000 },
  { id: 'w6', word: 'preliminary', meaning: '予備の、事前の', partOfSpeech: '形容詞', mastered: false, createdAt: Date.now() - 1000000 },
  { id: 'w7', word: 'compromise', meaning: '妥協する、歩み寄り', partOfSpeech: '名詞/動詞', mastered: true, createdAt: Date.now() - 900000 },
  { id: 'w8', word: 'versatile', meaning: '多才な、用途が広い', partOfSpeech: '形容詞', mastered: false, createdAt: Date.now() - 800000 },
  { id: 'w9', word: 'lucrative', meaning: '利益の上がる、儲かる', partOfSpeech: '形容詞', mastered: false, createdAt: Date.now() - 700000 },
  { id: 'w10', word: 'feasible', meaning: '実現可能な', partOfSpeech: '形容詞', mastered: true, createdAt: Date.now() - 600000 },
  { id: 'w11', word: 'comprehensive', meaning: '包括的な、総合的な', partOfSpeech: '形容詞', mastered: false, createdAt: Date.now() - 500000 },
  { id: 'w12', word: 'collaborate', meaning: '協力する、共同で作業する', partOfSpeech: '動詞', mastered: true, createdAt: Date.now() - 400000 },
  { id: 'w13', word: 'retain', meaning: 'を維持する、保持する', partOfSpeech: '動詞', mastered: false, createdAt: Date.now() - 300000 },
  { id: 'w14', word: 'ambiguous', meaning: '曖昧な、多義的な', partOfSpeech: '形容詞', mastered: false, createdAt: Date.now() - 200000 },
  { id: 'w15', word: 'substantial', meaning: 'かなりの、相当な、実質的な', partOfSpeech: '形容詞', mastered: false, createdAt: Date.now() - 100000 },
];

const LOCAL_STORAGE_WORDS_KEY = 'flashvocab_words_v1';
const LOCAL_STORAGE_STATS_KEY = 'flashvocab_stats_v1';
const LOCAL_STORAGE_APIKEY_KEY = 'flashvocab_gemini_key_v1';

// Natural fallback template sentences for registered words
const FALLBACK_TEMPLATES: Record<string, { sentence: string; translation: string }> = {
  resilient: {
    sentence: 'The local economy proved remarkably _____ in recovering from the disaster.',
    translation: '地域経済は災害からの復興において驚くべき回復力を発揮した。',
  },
  facilitate: {
    sentence: 'The new software is designed to _____ smooth communication among remote teams.',
    translation: '新しいソフトウェアはリモートチーム間の円滑なコミュニケーションを促進するよう設計されている。',
  },
  unprecedented: {
    sentence: 'The global market experienced an _____ surge in demand for clean energy.',
    translation: '世界市場はクリーンエネルギーに対する前例のない需要の急増を経験した。',
  },
  implement: {
    sentence: 'The committee decided to _____ the new policy starting next month.',
    translation: '委員会は来月から新しい方針を実行することを決定した。',
  },
  meticulous: {
    sentence: 'He conducted a _____ research investigation before publishing the findings.',
    translation: '彼は調査結果を発表する前に細心の注意を払った研究調査を実施した。',
  },
  preliminary: {
    sentence: 'The _____ results of the clinical trial showed great promise.',
    translation: '臨床試験の予備（事前）結果は大きな期待を示した。',
  },
  compromise: {
    sentence: 'Both parties were willing to reach a sensible _____ to close the deal.',
    translation: '双方は取引をまとめるために賢明な妥協に達する姿勢を見せた。',
  },
  versatile: {
    sentence: 'This smartphone camera is a _____ tool that performs well in low-light environments.',
    translation: 'このスマートフォンのカメラは暗所環境でも優れた性能を発揮する多才なツールだ。',
  },
  lucrative: {
    sentence: 'She secured a _____ contract with a multinational advertising agency.',
    translation: '彼女は多国籍広告代理店と利益の上がる有利な契約を結んだ。',
  },
  feasible: {
    sentence: 'After conducting market analysis, we found the proposal to be commercially _____.',
    translation: '市場分析を行った結果、その提案は商業的に実現可能であることが判明した。',
  },
  comprehensive: {
    sentence: 'The training manual provides a _____ overview of all security protocols.',
    translation: 'トレーニングマニュアルには全セキュリティ手順の包括的な概要が記載されている。',
  },
  collaborate: {
    sentence: 'Engineers and designers must _____ closely to produce top-tier digital products.',
    translation: '一流のデジタル製品を生み出すには、エンジニアとデザイナーが密接に協力しなければならない。',
  },
  retain: {
    sentence: 'The organization implemented flexible work hours to _____ talented employees.',
    translation: 'その組織は優秀な従業員を維持・定着させるために柔軟な勤務時間を導入した。',
  },
  ambiguous: {
    sentence: 'The wording in the agreement was somewhat _____, leading to misunderstandings.',
    translation: '合意書の文言はいくらか曖昧であり、誤解を招く結果となった。',
  },
  substantial: {
    sentence: 'The company reported a _____ increase in revenue over the last fiscal quarter.',
    translation: '会社は前四半期において売上高のかなりの（相当な）増加を報告した。',
  },
};

// ============================================================================
// Web Speech API Helper
// ============================================================================

function speakEnglish(text: string) {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
  try {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'en-US';
    utterance.rate = 0.92;
    window.speechSynthesis.speak(utterance);
  } catch (err) {
    console.error('TTS error:', err);
  }
}

// ============================================================================
// Main Application Component
// ============================================================================

export default function App() {
  // Navigation
  const [activeTab, setActiveTab] = useState<TabType>('flashcard');

  // Word Storage
  const [words, setWords] = useState<WordItem[]>(() => {
    try {
      const stored = localStorage.getItem(LOCAL_STORAGE_WORDS_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error('Failed to parse words from localStorage', e);
    }
    return DEFAULT_PRESET_WORDS;
  });

  // Save words to localStorage
  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_WORDS_KEY, JSON.stringify(words));
  }, [words]);

  // Quiz Stats Storage
  const [stats, setStats] = useState<QuizStats>(() => {
    try {
      const stored = localStorage.getItem(LOCAL_STORAGE_STATS_KEY);
      if (stored) return JSON.parse(stored);
    } catch (e) {
      console.error('Failed to parse quiz stats', e);
    }
    return {
      totalAnswered: 8,
      correctCount: 7,
      currentStreak: 3,
      bestStreak: 5,
      history: [
        { timestamp: Date.now() - 3600000 * 24 * 3, dateStr: '3日前', correct: true, targetWord: 'resilient' },
        { timestamp: Date.now() - 3600000 * 24 * 2, dateStr: '2日前', correct: true, targetWord: 'feasible' },
        { timestamp: Date.now() - 3600000 * 24 * 1, dateStr: '昨日', correct: false, targetWord: 'meticulous' },
        { timestamp: Date.now() - 3600000 * 12, dateStr: '今日', correct: true, targetWord: 'implement' },
      ],
    };
  });

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_STATS_KEY, JSON.stringify(stats));
  }, [stats]);

  // Gemini API Key Storage
  const [geminiApiKey, setGeminiApiKey] = useState<string>(() => {
    return localStorage.getItem(LOCAL_STORAGE_APIKEY_KEY) || '';
  });
  const [tempApiKey, setTempApiKey] = useState<string>(geminiApiKey);
  const [showApiKeyModal, setShowApiKeyModal] = useState<boolean>(false);
  const [showKeySecret, setShowKeySecret] = useState<boolean>(false);
  const [apiKeySuccessToast, setApiKeySuccessToast] = useState<boolean>(false);

  const handleSaveApiKey = () => {
    const trimmed = tempApiKey.trim();
    setGeminiApiKey(trimmed);
    localStorage.setItem(LOCAL_STORAGE_APIKEY_KEY, trimmed);
    setApiKeySuccessToast(true);
    setTimeout(() => {
      setApiKeySuccessToast(false);
      setShowApiKeyModal(false);
    }, 1200);
  };

  // --------------------------------------------------------------------------
  // PWA (Progressive Web App) Install State & Handlers
  // --------------------------------------------------------------------------
  interface BeforeInstallPromptEvent extends Event {
    prompt: () => Promise<void>;
    userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
  }

  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isStandalone, setIsStandalone] = useState<boolean>(false);
  const [isIOS, setIsIOS] = useState<boolean>(false);
  const [showIOSGuide, setShowIOSGuide] = useState<boolean>(false);

  useEffect(() => {
    // Check if running in standalone mode (already installed)
    const isStandaloneMode =
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as unknown as { standalone?: boolean }).standalone === true;
    setIsStandalone(isStandaloneMode);

    // Check if iOS
    const userAgent = window.navigator.userAgent.toLowerCase();
    const isIOSDevice = /iphone|ipad|ipod/.test(userAgent) && !(window as unknown as { MSStream?: unknown }).MSStream;
    setIsIOS(isIOSDevice);

    const handleBeforeInstall = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    const handleAppInstalled = () => {
      setIsStandalone(true);
      setDeferredPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  const handleInstallApp = async () => {
    if (deferredPrompt) {
      await deferredPrompt.prompt();
      const choice = await deferredPrompt.userChoice;
      if (choice.outcome === 'accepted') {
        setIsStandalone(true);
        setDeferredPrompt(null);
      }
    } else if (isIOS) {
      setShowIOSGuide(true);
    }
  };

  // --------------------------------------------------------------------------
  // Tab 1: Flashcard State
  // --------------------------------------------------------------------------
  const [cardIndex, setCardIndex] = useState<number>(0);
  const [isFlipped, setIsFlipped] = useState<boolean>(false);

  // If words array changes and cardIndex is out of range, clamp it
  useEffect(() => {
    if (cardIndex >= words.length && words.length > 0) {
      setCardIndex(0);
      setIsFlipped(false);
    }
  }, [words.length, cardIndex]);

  const currentCard = words[cardIndex] || null;

  const handleNextCard = () => {
    if (words.length === 0) return;
    setIsFlipped(false);
    setCardIndex((prev) => (prev + 1) % words.length);
  };

  const handlePrevCard = () => {
    if (words.length === 0) return;
    setIsFlipped(false);
    setCardIndex((prev) => (prev - 1 + words.length) % words.length);
  };

  const handleShuffleCards = () => {
    if (words.length <= 1) return;
    setIsFlipped(false);
    const shuffled = [...words].sort(() => Math.random() - 0.5);
    setWords(shuffled);
    setCardIndex(0);
  };

  const handleToggleCardMastered = (id: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setWords((prev) =>
      prev.map((w) => (w.id === id ? { ...w, mastered: !w.mastered } : w))
    );
  };

  // --------------------------------------------------------------------------
  // Tab 2: Word Registration & List State
  // --------------------------------------------------------------------------
  const [inputWord, setInputWord] = useState('');
  const [inputMeaning, setInputMeaning] = useState('');
  const [inputPos, setInputPos] = useState('形容詞');
  const [formSuccessMessage, setFormSuccessMessage] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'learning' | 'mastered'>('all');

  const handleAddWord = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputWord.trim() || !inputMeaning.trim()) return;

    const newWord: WordItem = {
      id: 'word_' + Date.now(),
      word: inputWord.trim(),
      meaning: inputMeaning.trim(),
      partOfSpeech: inputPos,
      mastered: false,
      createdAt: Date.now(),
    };

    setWords((prev) => [newWord, ...prev]);
    setInputWord('');
    setInputMeaning('');
    setFormSuccessMessage(`「${newWord.word}」を登録しました！`);
    setTimeout(() => setFormSuccessMessage(''), 2500);
  };

  const handleDeleteWord = (id: string, wordLabel: string) => {
    if (window.confirm(`「${wordLabel}」を単語帳から削除しますか？`)) {
      setWords((prev) => prev.filter((w) => w.id !== id));
    }
  };

  const handleResetPresets = () => {
    if (window.confirm('登録単語を初期プリセット（15語）にリセットしますか？')) {
      setWords(DEFAULT_PRESET_WORDS);
      setCardIndex(0);
      setIsFlipped(false);
    }
  };

  const filteredWords = useMemo(() => {
    return words.filter((w) => {
      const matchesSearch =
        w.word.toLowerCase().includes(searchQuery.toLowerCase()) ||
        w.meaning.toLowerCase().includes(searchQuery.toLowerCase());
      if (!matchesSearch) return false;

      if (filterType === 'mastered') return w.mastered;
      if (filterType === 'learning') return !w.mastered;
      return true;
    });
  }, [words, searchQuery, filterType]);

  // --------------------------------------------------------------------------
  // Tab 3: AI Quiz State & Gemini API Integration
  // --------------------------------------------------------------------------
  const [quizQuestion, setQuizQuestion] = useState<QuizQuestion | null>(null);
  const [quizLoading, setQuizLoading] = useState<boolean>(false);
  const [selectedChoiceIndex, setSelectedChoiceIndex] = useState<number | null>(null);
  const [hasAnswered, setHasAnswered] = useState<boolean>(false);
  const [quizError, setQuizError] = useState<string | null>(null);

  // Fallback Local Generator
  const generateLocalQuiz = useCallback(
    (targetItem: WordItem): QuizQuestion => {
      const template = FALLBACK_TEMPLATES[targetItem.word.toLowerCase()];
      let sentence = template
        ? template.sentence
        : `It is essential to understand the true value of _____ in this context.`;
      let translation = template
        ? template.translation
        : `この文脈において _____ の真の価値を理解することが不可欠です。`;
      let explanation = `正解は「${targetItem.word}（${targetItem.meaning}）」です。`;

      // Distractors from other words
      const otherWords = words.filter((w) => w.id !== targetItem.id);
      const shuffledOthers = [...otherWords].sort(() => Math.random() - 0.5);

      const dummyChoices: string[] = [];
      for (const w of shuffledOthers) {
        if (!dummyChoices.includes(w.word) && w.word !== targetItem.word) {
          dummyChoices.push(w.word);
        }
        if (dummyChoices.length >= 3) break;
      }

      // If not enough words in library, supplement with general vocabulary
      const fallbackDummies = ['essential', 'potential', 'significant', 'coherent', 'adequate', 'crucial'];
      for (const d of fallbackDummies) {
        if (dummyChoices.length >= 3) break;
        if (!dummyChoices.includes(d) && d !== targetItem.word) {
          dummyChoices.push(d);
        }
      }

      const allChoices = [targetItem.word, ...dummyChoices.slice(0, 3)].sort(() => Math.random() - 0.5);
      const correctIndex = allChoices.indexOf(targetItem.word);

      return {
        targetWord: targetItem.word,
        targetMeaning: targetItem.meaning,
        sentence,
        choices: allChoices,
        correctIndex,
        translation,
        explanation,
        isAiGenerated: false,
      };
    },
    [words]
  );

  // Gemini API Quiz Generator
  const fetchGeminiQuiz = async (targetItem: WordItem, apiKey: string): Promise<QuizQuestion> => {
    // Other words from user library as suggestions for distractors
    const otherWordCandidates = words
      .filter((w) => w.id !== targetItem.id)
      .map((w) => w.word)
      .slice(0, 5)
      .join(', ');

    const promptText = `
あなたは英語教育の専門家です。
以下の英単語を使って、穴埋め形式の4択クイズを1問作成し、必ずJSONフォーマットのみで返答してください。

【対象の正解英単語】: "${targetItem.word}" (意味: ${targetItem.meaning})
${otherWordCandidates ? `【他の登録単語候補（ダミーの参考に可）】: ${otherWordCandidates}` : ''}

【生成の要件】:
1. sentence: 正解の単語「${targetItem.word}」が入るべき自然な英語の例文（TOEICやビジネス・日常英会話で使える実用的な文）。単語が入る箇所を必ず「_____」（アンダースコア5つ）にしてください。
2. choices: 4つの選択肢の英単語配列。1つは正解「${targetItem.word}」、残りの3つは品詞や難易度が近い自然な不正解の英単語（ダミー単語）。
3. correctIndex: choices配列内での正解のインデックス番号 (0, 1, 2, 3 のいずれか)。
4. translation: 完成した英文の自然な日本語訳。
5. explanation: なぜその単語が当てはまるか、文脈と語彙の使い分けを解説する日本語（1〜2文）。

返答はMarkdownやコードブロック記号を入れず、以下のJSONオブジェクトのみを出力してください:
{
  "sentence": "例文...",
  "choices": ["単語1", "単語2", "単語3", "単語4"],
  "correctIndex": 0,
  "translation": "日本語訳...",
  "explanation": "解説..."
}
`;

    // Using gemini-2.5-flash as the latest standard fast model for structured generation
    const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${encodeURIComponent(
      apiKey
    )}`;

    const response = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: promptText }] }],
        generationConfig: {
          responseMimeType: 'application/json',
          temperature: 0.7,
        },
      }),
    });

    if (!response.ok) {
      const errBody = await response.text();
      throw new Error(`Gemini API エラー (${response.status}): ${errBody.slice(0, 150)}`);
    }

    const data = await response.json();
    const rawText = data?.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!rawText) throw new Error('Gemini APIから有効なテキストが返却されませんでした');

    const cleanJson = rawText.replace(/```json/g, '').replace(/```/g, '').trim();
    const parsed = JSON.parse(cleanJson);

    return {
      targetWord: targetItem.word,
      targetMeaning: targetItem.meaning,
      sentence: parsed.sentence || `He decided to _____ the new plan.`,
      choices: parsed.choices || [targetItem.word, 'obscure', 'hostile', 'rigid'],
      correctIndex: typeof parsed.correctIndex === 'number' ? parsed.correctIndex : 0,
      translation: parsed.translation || '日本語訳',
      explanation: parsed.explanation || `「${targetItem.word}」が文脈上最も適切です。`,
      isAiGenerated: true,
    };
  };

  const handleStartNextQuiz = useCallback(async () => {
    if (words.length === 0) return;
    setQuizLoading(true);
    setQuizError(null);
    setSelectedChoiceIndex(null);
    setHasAnswered(false);

    // Pick target word, prioritizing words that are still "learning"
    const unmastered = words.filter((w) => !w.mastered);
    const pool = unmastered.length > 0 && Math.random() < 0.75 ? unmastered : words;
    const targetWordItem = pool[Math.floor(Math.random() * pool.length)];

    if (geminiApiKey.trim()) {
      try {
        const question = await fetchGeminiQuiz(targetWordItem, geminiApiKey.trim());
        setQuizQuestion(question);
      } catch (err: unknown) {
        console.warn('Gemini API failed, falling back to local quiz generator:', err);
        const errMsg = err instanceof Error ? err.message : String(err);
        setQuizError(`Gemini API通信に失敗したため、ローカル出題に切り替えました (${errMsg})`);
        const fallback = generateLocalQuiz(targetWordItem);
        setQuizQuestion(fallback);
      } finally {
        setQuizLoading(false);
      }
    } else {
      // Local generator immediately
      const fallback = generateLocalQuiz(targetWordItem);
      setQuizQuestion(fallback);
      setQuizLoading(false);
    }
  }, [words, geminiApiKey, generateLocalQuiz]);

  // Auto load first question when navigating to quiz tab
  useEffect(() => {
    if (activeTab === 'quiz' && !quizQuestion && words.length > 0 && !quizLoading) {
      handleStartNextQuiz();
    }
  }, [activeTab, quizQuestion, words.length, quizLoading, handleStartNextQuiz]);

  const handleSelectChoice = (index: number) => {
    if (hasAnswered || !quizQuestion) return;

    setSelectedChoiceIndex(index);
    setHasAnswered(true);

    const isCorrect = index === quizQuestion.correctIndex;

    // Update stats
    setStats((prev) => {
      const newTotal = prev.totalAnswered + 1;
      const newCorrect = prev.correctCount + (isCorrect ? 1 : 0);
      const newStreak = isCorrect ? prev.currentStreak + 1 : 0;
      const newBest = Math.max(prev.bestStreak, newStreak);
      const newRecord: QuizHistoryRecord = {
        timestamp: Date.now(),
        dateStr: '今回',
        correct: isCorrect,
        targetWord: quizQuestion.targetWord,
      };

      return {
        totalAnswered: newTotal,
        correctCount: newCorrect,
        currentStreak: newStreak,
        bestStreak: newBest,
        history: [newRecord, ...prev.history.slice(0, 9)], // keep last 10
      };
    });

    // Automatically speak the target word upon answer
    speakEnglish(quizQuestion.targetWord);
  };

  // --------------------------------------------------------------------------
  // Tab 4: Dashboard Metrics Calculations
  // --------------------------------------------------------------------------
  const masteredCount = useMemo(() => words.filter((w) => w.mastered).length, [words]);
  const learningCount = words.length - masteredCount;
  const masterPercentage = words.length > 0 ? Math.round((masteredCount / words.length) * 100) : 0;
  const accuracyPercentage =
    stats.totalAnswered > 0 ? Math.round((stats.correctCount / stats.totalAnswered) * 100) : 0;

  // Donut chart math
  const donutRadius = 54;
  const donutCircumference = 2 * Math.PI * donutRadius;
  const masteredStrokeOffset = donutCircumference - (masterPercentage / 100) * donutCircumference;

  return (
    <div className="app-container">
      {/* Top Header Bar */}
      <header className="top-nav">
        <div className="brand-wrap">
          <div className="brand-icon">
            <BookOpen size={18} />
          </div>
          <span className="brand-title">FlashVocab Studio</span>
          <span className="brand-tag">v1.0</span>
        </div>

        <div className="top-actions">
          {!isStandalone && (deferredPrompt || isIOS) && (
            <button
              onClick={handleInstallApp}
              className="key-status-btn"
              style={{
                backgroundColor: 'var(--primary-light)',
                color: 'var(--primary)',
                borderColor: 'var(--primary-border)',
                fontWeight: 600,
              }}
              title="ホーム画面にアプリをインストール"
            >
              <Download size={14} />
              <span>{isIOS ? 'ホームに追加' : 'インストール'}</span>
            </button>
          )}

          <button
            onClick={() => {
              setTempApiKey(geminiApiKey);
              setShowApiKeyModal(true);
            }}
            className={`key-status-btn ${geminiApiKey.trim() ? 'active' : ''}`}
            title="Gemini APIキー設定"
          >
            <Key size={14} />
            <span>{geminiApiKey.trim() ? 'Gemini AI 連携中' : 'APIキー設定'}</span>
          </button>
        </div>
      </header>

      {/* Main Content Body */}
      <main className="main-content">
        {/* Navigation Tabs (Top on Desktop, Fixed Bottom on Mobile) */}
        <nav className="nav-tab-bar" aria-label="Main Navigation">
          <button
            onClick={() => setActiveTab('flashcard')}
            className={`tab-btn ${activeTab === 'flashcard' ? 'active' : ''}`}
          >
            <BookOpen size={18} />
            <span>フラッシュカード</span>
          </button>
          <button
            onClick={() => setActiveTab('register')}
            className={`tab-btn ${activeTab === 'register' ? 'active' : ''}`}
          >
            <Plus size={18} />
            <span>単語登録・管理</span>
          </button>
          <button
            onClick={() => setActiveTab('quiz')}
            className={`tab-btn ${activeTab === 'quiz' ? 'active' : ''}`}
          >
            <BrainCircuit size={18} />
            <span>AI例文クイズ</span>
          </button>
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`tab-btn ${activeTab === 'dashboard' ? 'active' : ''}`}
          >
            <BarChart3 size={18} />
            <span>進捗ダッシュボード</span>
          </button>
        </nav>

        {/* ================================================================== */}
        {/* VIEW 1: FLASHCARD (MAIN)                                           */}
        {/* ================================================================== */}
        {activeTab === 'flashcard' && (
          <div className="tab-pane">
            {words.length === 0 ? (
              <div className="empty-state">
                <BookOpen size={48} className="empty-icon" />
                <h3 className="empty-title">単語が登録されていません</h3>
                <p className="empty-desc">
                  「単語登録」画面から新しい英単語を追加するか、初期プリセットを読み込んでください。
                </p>
                <button onClick={handleResetPresets} className="btn-primary">
                  <RotateCcw size={16} />
                  <span>初期プリセット単語を読み込む</span>
                </button>
              </div>
            ) : (
              <div>
                {/* Flashcard Header Controls */}
                <div className="flashcard-header">
                  <span className="counter-badge num-tabular">
                    単語 {cardIndex + 1} / {words.length}
                  </span>
                  <div className="flashcard-controls-top">
                    <button
                      onClick={handleShuffleCards}
                      className="icon-btn-secondary"
                      title="単語の並び順をシャッフル"
                    >
                      <Shuffle size={16} />
                    </button>
                    <button
                      onClick={() => setIsFlipped(!isFlipped)}
                      className="icon-btn-secondary"
                      title="カードを裏返す"
                    >
                      <RotateCw size={16} />
                    </button>
                  </div>
                </div>

                {/* 3D Perspective Card Stage */}
                <div
                  className="flashcard-stage"
                  onClick={() => setIsFlipped(!isFlipped)}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === ' ' || e.key === 'Enter') {
                      e.preventDefault();
                      setIsFlipped(!isFlipped);
                    } else if (e.key === 'ArrowRight') {
                      handleNextCard();
                    } else if (e.key === 'ArrowLeft') {
                      handlePrevCard();
                    }
                  }}
                  aria-label="フラッシュカード（タップで裏返し）"
                >
                  <div className={`flashcard-3d ${isFlipped ? 'flipped' : ''}`}>
                    {/* Front Face (English) */}
                    <div className="card-face card-face-front">
                      <div className="card-top-row">
                        <span className="card-side-tag">FRONT · 英語</span>
                        <span
                          className={`card-status-pill ${
                            currentCard?.mastered ? 'mastered' : 'learning'
                          }`}
                        >
                          {currentCard?.mastered ? '✓ 習得済み' : '● 学習中'}
                        </span>
                      </div>

                      <div className="card-center-content">
                        <h2 className="card-word-display">{currentCard?.word}</h2>
                        <span className="card-part-of-speech">
                          [{currentCard?.partOfSpeech || '単語'}]
                        </span>

                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            if (currentCard) speakEnglish(currentCard.word);
                          }}
                          className="card-audio-btn"
                          title="ネイティブ発音を再生"
                        >
                          <Volume2 size={16} />
                          <span>発音を聞く</span>
                        </button>
                      </div>

                      <div className="card-bottom-hint">
                        <RotateCw size={14} />
                        <span>タップして日本語訳を表示</span>
                      </div>
                    </div>

                    {/* Back Face (Japanese) */}
                    <div className="card-face card-face-back">
                      <div className="card-top-row">
                        <span className="card-side-tag">BACK · 日本語訳</span>
                        <span
                          className={`card-status-pill ${
                            currentCard?.mastered ? 'mastered' : 'learning'
                          }`}
                        >
                          {currentCard?.mastered ? '✓ 習得済み' : '● 学習中'}
                        </span>
                      </div>

                      <div className="card-center-content">
                        <h3 className="card-meaning-display">{currentCard?.meaning}</h3>
                        <p style={{ color: 'var(--text-secondary)', fontSize: '0.95rem' }}>
                          英単語: <strong>{currentCard?.word}</strong>
                        </p>

                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            if (currentCard) speakEnglish(currentCard.word);
                          }}
                          className="card-audio-btn"
                        >
                          <Volume2 size={16} />
                          <span>単語をリピート</span>
                        </button>
                      </div>

                      <div className="card-bottom-hint">
                        <RotateCw size={14} />
                        <span>タップして表面に戻す</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Bottom Navigation & Status Toggle Controls */}
                <div className="card-nav-cluster">
                  <button onClick={handlePrevCard} className="btn-nav">
                    <ChevronLeft size={18} />
                    <span>前の単語</span>
                  </button>

                  {currentCard && (
                    <button
                      onClick={(e) => handleToggleCardMastered(currentCard.id, e)}
                      className={`btn-status-toggle ${
                        currentCard.mastered ? 'is-mastered' : 'is-learning'
                      }`}
                      title={currentCard.mastered ? '学習中に戻す' : '習得済みにマーク'}
                    >
                      <Check size={16} />
                      <span>{currentCard.mastered ? '習得済' : '覚えた!'}</span>
                    </button>
                  )}

                  <button onClick={handleNextCard} className="btn-nav">
                    <span>次の単語</span>
                    <ChevronRight size={18} />
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ================================================================== */}
        {/* VIEW 2: WORD REGISTRATION & LIST SCREEN                             */}
        {/* ================================================================== */}
        {activeTab === 'register' && (
          <div className="tab-pane">
            {/* Registration Form */}
            <div className="section-card">
              <h2 className="section-title">
                <Plus size={20} style={{ color: 'var(--primary)' }} />
                <span>新しい英単語を登録</span>
              </h2>
              <p className="section-desc">
                覚えたて、またはこれから覚えたい英単語やフレーズを登録してください。ブラウザに自動保存されます。
              </p>

              <form onSubmit={handleAddWord}>
                <div className="form-grid">
                  <div className="form-group">
                    <label className="form-label" htmlFor="word-input">
                      英単語 / フレーズ *
                    </label>
                    <input
                      id="word-input"
                      type="text"
                      className="input-text"
                      placeholder="例: persistent, take advantage of"
                      value={inputWord}
                      onChange={(e) => setInputWord(e.target.value)}
                      required
                    />
                  </div>

                  <div className="form-grid form-grid-2">
                    <div className="form-group">
                      <label className="form-label" htmlFor="meaning-input">
                        日本語訳 *
                      </label>
                      <input
                        id="meaning-input"
                        type="text"
                        className="input-text"
                        placeholder="例: 粘り強い、持続する"
                        value={inputMeaning}
                        onChange={(e) => setInputMeaning(e.target.value)}
                        required
                      />
                    </div>

                    <div className="form-group">
                      <label className="form-label" htmlFor="pos-select">
                        品詞 / 分類
                      </label>
                      <select
                        id="pos-select"
                        className="input-select"
                        value={inputPos}
                        onChange={(e) => setInputPos(e.target.value)}
                      >
                        <option value="形容詞">形容詞 (Adjective)</option>
                        <option value="動詞">動詞 (Verb)</option>
                        <option value="名詞">名詞 (Noun)</option>
                        <option value="副詞">副詞 (Adverb)</option>
                        <option value="熟語/フレーズ">熟語/フレーズ (Idiom/Phrase)</option>
                        <option value="その他">その他 (Other)</option>
                      </select>
                    </div>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: '6px' }}>
                    {formSuccessMessage ? (
                      <span style={{ color: 'var(--success)', fontSize: '0.86rem', fontWeight: 600 }}>
                        ✓ {formSuccessMessage}
                      </span>
                    ) : <span />}
                    <button type="submit" className="btn-primary">
                      <Plus size={16} />
                      <span>単語帳に追加する</span>
                    </button>
                  </div>
                </div>
              </form>
            </div>

            {/* Word List Section */}
            <div className="section-card">
              <div className="list-toolbar">
                <div className="search-input-wrap">
                  <Search size={16} className="search-icon" />
                  <input
                    type="text"
                    className="input-search"
                    placeholder="単語または日本語で検索..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>

                <div className="filter-segments">
                  <button
                    onClick={() => setFilterType('all')}
                    className={`segment-btn ${filterType === 'all' ? 'active' : ''}`}
                  >
                    すべて ({words.length})
                  </button>
                  <button
                    onClick={() => setFilterType('learning')}
                    className={`segment-btn ${filterType === 'learning' ? 'active' : ''}`}
                  >
                    学習中 ({learningCount})
                  </button>
                  <button
                    onClick={() => setFilterType('mastered')}
                    className={`segment-btn ${filterType === 'mastered' ? 'active' : ''}`}
                  >
                    習得済み ({masteredCount})
                  </button>
                </div>
              </div>

              {filteredWords.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '36px 12px', color: 'var(--text-muted)' }}>
                  該当する単語が見つかりませんでした。
                </div>
              ) : (
                <div className="word-list">
                  {filteredWords.map((item) => (
                    <div key={item.id} className="word-row">
                      <div className="word-row-main">
                        <div className="word-row-title-wrap">
                          <span className="word-row-text">{item.word}</span>
                          <span className="word-row-pos">[{item.partOfSpeech}]</span>
                          <span
                            className={`card-status-pill ${item.mastered ? 'mastered' : 'learning'}`}
                            style={{ fontSize: '0.7rem', padding: '2px 8px' }}
                          >
                            {item.mastered ? '習得済' : '学習中'}
                          </span>
                        </div>
                        <div className="word-row-meaning">{item.meaning}</div>
                      </div>

                      <div className="word-row-actions">
                        <button
                          onClick={() => speakEnglish(item.word)}
                          className="icon-btn-secondary"
                          style={{ width: '34px', height: '34px' }}
                          title="発音を聴く"
                        >
                          <Volume2 size={16} />
                        </button>
                        <button
                          onClick={(e) => handleToggleCardMastered(item.id, e)}
                          className={`icon-btn-secondary ${item.mastered ? 'active' : ''}`}
                          style={{
                            width: '34px',
                            height: '34px',
                            color: item.mastered ? 'var(--success)' : 'inherit',
                          }}
                          title={item.mastered ? '未習得に戻す' : '習得済みにする'}
                        >
                          <Check size={16} />
                        </button>
                        <button
                          onClick={() => handleDeleteWord(item.id, item.word)}
                          className="icon-btn-danger"
                          title="削除"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Reset to Presets Link */}
              <div style={{ marginTop: '20px', textAlign: 'right' }}>
                <button
                  onClick={handleResetPresets}
                  style={{
                    background: 'none',
                    border: 'none',
                    color: 'var(--text-muted)',
                    fontSize: '0.78rem',
                    cursor: 'pointer',
                    textDecoration: 'underline',
                  }}
                >
                  初期プリセット英単語を再読み込み
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ================================================================== */}
        {/* VIEW 3: AI SENTENCE QUIZ SCREEN (GEMINI API INTEGRATION)           */}
        {/* ================================================================== */}
        {activeTab === 'quiz' && (
          <div className="tab-pane">
            {words.length === 0 ? (
              <div className="empty-state">
                <BrainCircuit size={48} className="empty-icon" />
                <h3 className="empty-title">クイズ用単語がありません</h3>
                <p className="empty-desc">
                  クイズを出題するには、まず単語帳に英単語を登録してください。
                </p>
                <button onClick={handleResetPresets} className="btn-primary">
                  <RotateCcw size={16} />
                  <span>初期プリセットを読み込む</span>
                </button>
              </div>
            ) : (
              <div>
                {/* Active Mode Banner */}
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    background: '#fff',
                    padding: '12px 18px',
                    borderRadius: 'var(--radius-lg)',
                    border: '1px solid var(--border-light)',
                    marginBottom: '16px',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <Sparkles
                      size={18}
                      style={{ color: geminiApiKey ? 'var(--primary)' : 'var(--text-muted)' }}
                    />
                    <div>
                      <span style={{ fontSize: '0.86rem', fontWeight: 600 }}>
                        {geminiApiKey
                          ? 'Gemini 3.8 Flash AI 例文生成モード'
                          : 'ローカル模試モード（APIキー不要）'}
                      </span>
                      <span
                        style={{
                          display: 'block',
                          fontSize: '0.74rem',
                          color: 'var(--text-secondary)',
                        }}
                      >
                        {geminiApiKey
                          ? 'Geminiが登録単語からリアルタイムに文脈例文を生成します'
                          : 'APIキーを設定するとGeminiによる無限AI例文クイズが有効になります'}
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      setTempApiKey(geminiApiKey);
                      setShowApiKeyModal(true);
                    }}
                    style={{
                      border: '1px solid var(--border-subtle)',
                      background: 'var(--bg-subtle)',
                      padding: '6px 12px',
                      borderRadius: 'var(--radius-md)',
                      fontSize: '0.78rem',
                      fontWeight: 600,
                      cursor: 'pointer',
                    }}
                  >
                    設定変更
                  </button>
                </div>

                {quizError && (
                  <div
                    style={{
                      background: 'var(--danger-light)',
                      border: '1px solid var(--danger-border)',
                      color: 'var(--danger)',
                      padding: '10px 14px',
                      borderRadius: 'var(--radius-md)',
                      fontSize: '0.8rem',
                      marginBottom: '16px',
                    }}
                  >
                    {quizError}
                  </div>
                )}

                {/* Main Quiz Box */}
                <div className="quiz-card">
                  <div className="quiz-header-bar">
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <span className={`quiz-mode-pill ${quizQuestion?.isAiGenerated ? '' : 'local'}`}>
                        {quizQuestion?.isAiGenerated ? '✦ Gemini AI 生成' : '● ローカル文脈'}
                      </span>
                      <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                        出題単語: <strong>{quizQuestion?.targetWord}</strong>
                      </span>
                    </div>

                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                      <Flame size={16} style={{ color: '#ea580c' }} />
                      <span style={{ fontSize: '0.82rem', fontWeight: 700 }} className="num-tabular">
                        連続 {stats.currentStreak} 問
                      </span>
                    </div>
                  </div>

                  {quizLoading ? (
                    <div style={{ padding: '60px 0', textAlign: 'center' }}>
                      <div className="spinner-inline" style={{ borderColor: 'var(--primary) transparent var(--primary) transparent', width: '28px', height: '28px', borderWidth: '3px' }} />
                      <p style={{ marginTop: '14px', fontSize: '0.9rem', color: 'var(--text-secondary)' }}>
                        {geminiApiKey ? 'Gemini AI が自然な英文と選択肢を生成中...' : 'クイズを準備中...'}
                      </p>
                    </div>
                  ) : quizQuestion ? (
                    <div>
                      {/* Sentence with Blank (_____ ) */}
                      <div className="quiz-sentence-box">
                        <p className="quiz-sentence-text">
                          {quizQuestion.sentence.split('_____').map((part, i, arr) => (
                            <React.Fragment key={i}>
                              {part}
                              {i < arr.length - 1 && (
                                <span className="quiz-blank-highlight">
                                  {hasAnswered ? quizQuestion.targetWord : '_____'}
                                </span>
                              )}
                            </React.Fragment>
                          ))}
                        </p>

                        <div style={{ display: 'flex', justifyContent: 'center', marginTop: '10px' }}>
                          <button
                            onClick={() => speakEnglish(quizQuestion.sentence.replace('_____', quizQuestion.targetWord))}
                            className="card-audio-btn"
                            style={{ margin: 0 }}
                          >
                            <Volume2 size={16} />
                            <span>英文全体を再生</span>
                          </button>
                        </div>
                      </div>

                      {/* 4 Choices */}
                      <div className="quiz-choices-grid">
                        {quizQuestion.choices.map((choice, index) => {
                          const isSelected = selectedChoiceIndex === index;
                          const isCorrect = index === quizQuestion.correctIndex;

                          let stateClass = '';
                          if (hasAnswered) {
                            if (isSelected) {
                              stateClass = isCorrect ? 'selected-correct' : 'selected-wrong';
                            } else if (isCorrect) {
                              stateClass = 'reveal-correct';
                            }
                          }

                          const letter = String.fromCharCode(65 + index);

                          return (
                            <button
                              key={index}
                              onClick={() => handleSelectChoice(index)}
                              disabled={hasAnswered}
                              className={`quiz-choice-btn ${stateClass}`}
                            >
                              <span className="choice-letter-badge">{letter}</span>
                              <span style={{ flex: 1 }}>{choice}</span>
                              {hasAnswered && isCorrect && (
                                <CheckCircle2 size={20} style={{ color: 'var(--success)' }} />
                              )}
                              {hasAnswered && isSelected && !isCorrect && (
                                <XCircle size={20} style={{ color: 'var(--danger)' }} />
                              )}
                            </button>
                          );
                        })}
                      </div>

                      {/* Post-Answer Result & Explanation */}
                      {hasAnswered && (
                        <div
                          className={`quiz-result-banner ${
                            selectedChoiceIndex === quizQuestion.correctIndex ? 'correct' : 'wrong'
                          }`}
                        >
                          <div className="quiz-result-title">
                            {selectedChoiceIndex === quizQuestion.correctIndex ? (
                              <>
                                <CheckCircle2 size={22} />
                                <span>正解です！ Great job!</span>
                              </>
                            ) : (
                              <>
                                <XCircle size={22} />
                                <span>不正解です（正解: {quizQuestion.targetWord}）</span>
                              </>
                            )}
                          </div>

                          <div className="quiz-translation-text">
                            <strong>和訳: </strong>
                            {quizQuestion.translation}
                          </div>

                          <div className="quiz-explanation-text">
                            <strong>解説: </strong>
                            {quizQuestion.explanation}
                          </div>

                          <div style={{ marginTop: '16px', display: 'flex', gap: '10px' }}>
                            <button
                              onClick={() => speakEnglish(quizQuestion.targetWord)}
                              className="btn-nav"
                              style={{ flex: 'none', padding: '8px 16px', minHeight: '40px', fontSize: '0.84rem' }}
                            >
                              <Volume2 size={16} />
                              <span>単語発音</span>
                            </button>
                            <button
                              onClick={handleStartNextQuiz}
                              className="btn-primary"
                              style={{ flex: 1 }}
                            >
                              <span>次の問題に挑戦</span>
                              <ChevronRight size={18} />
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  ) : null}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ================================================================== */}
        {/* VIEW 4: PROGRESS DASHBOARD & SVG CHARTS                            */}
        {/* ================================================================== */}
        {activeTab === 'dashboard' && (
          <div className="tab-pane">
            {/* Metric Tiles */}
            <div className="stats-grid">
              <div className="stat-tile">
                <span className="stat-tile-label">総登録単語</span>
                <span className="stat-tile-value num-tabular">{words.length}</span>
                <span className="stat-tile-sub">単語帳の語彙数</span>
              </div>

              <div className="stat-tile">
                <span className="stat-tile-label">習得済み</span>
                <span className="stat-tile-value num-tabular" style={{ color: 'var(--success)' }}>
                  {masteredCount}
                </span>
                <span className="stat-tile-sub">全体の {masterPercentage}%</span>
              </div>

              <div className="stat-tile">
                <span className="stat-tile-label">クイズ正答率</span>
                <span className="stat-tile-value num-tabular" style={{ color: 'var(--primary)' }}>
                  {accuracyPercentage}%
                </span>
                <span className="stat-tile-sub">
                  {stats.correctCount} / {stats.totalAnswered} 問正解
                </span>
              </div>

              <div className="stat-tile">
                <span className="stat-tile-label">連続正解</span>
                <span className="stat-tile-value num-tabular" style={{ color: '#ea580c' }}>
                  {stats.currentStreak}
                </span>
                <span className="stat-tile-sub">最高記録: {stats.bestStreak}問</span>
              </div>
            </div>

            {/* Charts Row */}
            <div className="chart-columns">
              {/* Donut Chart: Memorization Ratio */}
              <div className="chart-card">
                <div className="chart-title">
                  <span>単語暗記の達成度</span>
                  <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                    達成率: {masterPercentage}%
                  </span>
                </div>

                <div className="donut-chart-wrap">
                  <svg width="150" height="150" viewBox="0 0 140 140" className="donut-svg">
                    {/* Background Circle */}
                    <circle
                      cx="70"
                      cy="70"
                      r={donutRadius}
                      fill="transparent"
                      stroke="#e2e8f0"
                      strokeWidth="14"
                    />
                    {/* Learning Portion */}
                    <circle
                      cx="70"
                      cy="70"
                      r={donutRadius}
                      fill="transparent"
                      stroke="#f59e0b"
                      strokeWidth="14"
                      strokeDasharray={donutCircumference}
                      strokeDashoffset="0"
                    />
                    {/* Mastered Portion */}
                    <circle
                      cx="70"
                      cy="70"
                      r={donutRadius}
                      fill="transparent"
                      stroke="#10b981"
                      strokeWidth="14"
                      strokeDasharray={donutCircumference}
                      strokeDashoffset={masteredStrokeOffset}
                      strokeLinecap="round"
                    />
                    {/* Text in Center */}
                    <text
                      x="70"
                      y="68"
                      transform="rotate(90 70 70)"
                      textAnchor="middle"
                      dominantBaseline="middle"
                      fontSize="20"
                      fontWeight="800"
                      fill="#0f172a"
                    >
                      {masterPercentage}%
                    </text>
                    <text
                      x="70"
                      y="88"
                      transform="rotate(90 70 70)"
                      textAnchor="middle"
                      dominantBaseline="middle"
                      fontSize="10"
                      fontWeight="600"
                      fill="#64748b"
                    >
                      習得済み
                    </text>
                  </svg>

                  <div className="donut-legend">
                    <div className="legend-item">
                      <span className="legend-dot" style={{ background: '#10b981' }} />
                      <span>習得済み ({masteredCount}語)</span>
                    </div>
                    <div className="legend-item">
                      <span className="legend-dot" style={{ background: '#f59e0b' }} />
                      <span>学習中 ({learningCount}語)</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Bar Chart: Recent Quiz Sessions Performance */}
              <div className="chart-card">
                <div className="chart-title">
                  <span>直近のクイズ履歴</span>
                  <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                    正答数: {stats.correctCount} / {stats.totalAnswered}
                  </span>
                </div>

                <div className="bar-chart-container">
                  {stats.history.length === 0 ? (
                    <div style={{ width: '100%', textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.84rem' }}>
                      クイズに挑戦すると履歴が表示されます
                    </div>
                  ) : (
                    stats.history.slice(0, 6).map((rec, i) => (
                      <div key={i} className="bar-column">
                        <span className="bar-value">
                          {rec.correct ? '○' : '×'}
                        </span>
                        <div
                          className="bar-pill"
                          style={{
                            height: rec.correct ? '90%' : '35%',
                            background: rec.correct
                              ? 'linear-gradient(180deg, #10b981, #059669)'
                              : 'linear-gradient(180deg, #f87171, #dc2626)',
                          }}
                        />
                        <span className="bar-label">{rec.targetWord.slice(0, 5)}..</span>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>

            {/* Recommendations / Encouragement Card */}
            <div
              style={{
                background: 'linear-gradient(135deg, #eef2ff 0%, #faf5ff 100%)',
                border: '1px solid #c7d2fe',
                borderRadius: 'var(--radius-xl)',
                padding: '20px 24px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                flexWrap: 'wrap',
                gap: '16px',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
                <div
                  style={{
                    width: '44px',
                    height: '44px',
                    borderRadius: '50%',
                    background: '#4338ca',
                    color: '#fff',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Award size={22} />
                </div>
                <div>
                  <h4 style={{ fontSize: '1rem', fontWeight: 700, color: 'var(--text-main)', marginBottom: '2px' }}>
                    {learningCount > 0
                      ? `未習得の単語が ${learningCount} 語あります`
                      : '登録された全単語をマスターしました！'}
                  </h4>
                  <p style={{ fontSize: '0.82rem', color: 'var(--text-secondary)' }}>
                    フラッシュカードで復習するか、AI例文クイズで実際の文脈での使い方を試しましょう。
                  </p>
                </div>
              </div>

              <div style={{ display: 'flex', gap: '8px' }}>
                <button
                  onClick={() => setActiveTab('flashcard')}
                  className="btn-nav"
                  style={{ minHeight: '40px', fontSize: '0.84rem' }}
                >
                  カードで復習
                </button>
                <button
                  onClick={() => setActiveTab('quiz')}
                  className="btn-primary"
                  style={{ minHeight: '40px', fontSize: '0.84rem' }}
                >
                  クイズで特訓
                </button>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* ==================================================================== */}
      {/* Gemini API Key Settings Modal                                        */}
      {/* ==================================================================== */}
      {showApiKeyModal && (
        <div className="modal-overlay" onClick={() => setShowApiKeyModal(false)}>
          <div className="modal-card" onClick={(e) => e.stopPropagation()}>
            <div className="api-key-header">
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Key size={20} style={{ color: 'var(--primary)' }} />
                <h3 style={{ fontSize: '1.1rem', fontWeight: 700 }}>Gemini API キー設定</h3>
              </div>
              <button
                onClick={() => setShowApiKeyModal(false)}
                className="icon-btn-secondary"
                style={{ width: '32px', height: '32px' }}
              >
                ✕
              </button>
            </div>

            <p style={{ fontSize: '0.84rem', color: 'var(--text-secondary)', marginBottom: '14px', lineHeight: 1.5 }}>
              Google AI Studioから取得したGemini APIキーを入力すると、登録単語に合わせた自然な英文クイズをリアルタイムに自動生成できます。キーはお使いの端末のブラウザ内（localStorage）にのみ安全に保存されます。
            </p>

            <div className="form-group" style={{ marginBottom: '16px' }}>
              <label className="form-label" htmlFor="gemini-key-input">
                API キー (AIzaSy...)
              </label>
              <div style={{ position: 'relative' }}>
                <input
                  id="gemini-key-input"
                  type={showKeySecret ? 'text' : 'password'}
                  className="input-text"
                  style={{ paddingRight: '40px' }}
                  placeholder="AIzaSy..."
                  value={tempApiKey}
                  onChange={(e) => setTempApiKey(e.target.value)}
                />
                <button
                  type="button"
                  onClick={() => setShowKeySecret(!showKeySecret)}
                  style={{
                    position: 'absolute',
                    right: '10px',
                    top: '50%',
                    transform: 'translateY(-50%)',
                    background: 'none',
                    border: 'none',
                    cursor: 'pointer',
                    color: 'var(--text-muted)',
                  }}
                >
                  {showKeySecret ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {apiKeySuccessToast && (
              <div
                style={{
                  background: 'var(--success-light)',
                  color: 'var(--success)',
                  border: '1px solid var(--success-border)',
                  padding: '8px 12px',
                  borderRadius: 'var(--radius-md)',
                  fontSize: '0.82rem',
                  fontWeight: 600,
                  marginBottom: '14px',
                }}
              >
                ✓ APIキーを保存しました！
              </div>
            )}

            <div style={{ display: 'flex', gap: '8px', justifyContent: 'flex-end' }}>
              {geminiApiKey && (
                <button
                  type="button"
                  onClick={() => {
                    setGeminiApiKey('');
                    setTempApiKey('');
                    localStorage.removeItem(LOCAL_STORAGE_APIKEY_KEY);
                  }}
                  className="btn-nav"
                  style={{ color: 'var(--danger)', borderColor: 'var(--danger-border)' }}
                >
                  キーを解除
                </button>
              )}
              <button
                type="button"
                onClick={() => setShowApiKeyModal(false)}
                className="btn-nav"
              >
                キャンセル
              </button>
              <button
                type="button"
                onClick={handleSaveApiKey}
                className="btn-primary"
              >
                保存する
              </button>
            </div>
          </div>
        </div>
      )}

      {/* iOS Safari PWA Install Guide Modal */}
      {showIOSGuide && (
        <div className="modal-overlay" onClick={() => setShowIOSGuide(false)}>
          <div className="modal-card" onClick={(e) => e.stopPropagation()}>
            <div className="api-key-header">
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Download size={20} style={{ color: 'var(--primary)' }} />
                <h3 style={{ fontSize: '1.1rem', fontWeight: 700 }}>iPhone / iPad でのインストール</h3>
              </div>
              <button
                onClick={() => setShowIOSGuide(false)}
                className="icon-btn-secondary"
                style={{ width: '32px', height: '32px' }}
              >
                ✕
              </button>
            </div>

            <p style={{ fontSize: '0.86rem', color: 'var(--text-secondary)', marginBottom: '14px', lineHeight: 1.6 }}>
              Safariブラウザから簡単にホーム画面にアプリアイコンを追加し、全画面で快適にご利用いただけます:
            </p>

            <ol style={{ paddingLeft: '20px', fontSize: '0.86rem', color: 'var(--text-main)', display: 'flex', flexDirection: 'column', gap: '8px', marginBottom: '20px' }}>
              <li>Safari下部のメニューバーにある<strong>「共有」ボタン（四角に上向き矢印）</strong>をタップします。</li>
              <li>メニューを少し下にスクロールして<strong>「ホーム画面に追加」</strong>をタップします。</li>
              <li>右上の<strong>「追加」</strong>をタップすると、ホーム画面に単語帳アプリが配置されます。</li>
            </ol>

            <button
              type="button"
              onClick={() => setShowIOSGuide(false)}
              className="btn-primary"
              style={{ width: '100%' }}
            >
              閉じる
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
